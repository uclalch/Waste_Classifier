//
//  active_camera.swift
//  MLModelCamera
//
//  Created by Lichaohao on 2019/12/2.
//  Copyright © 2019 Shuichi Tsutsumi. All rights reserved.
//

import UIKit
import FirebaseCore

class Active_camera: UIViewController {

    var window: UIWindow?
    
    override func loadView() {

    }
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        window = UIWindow(frame: UIScreen.main.bounds)
                let rootViewController = RootViewController()
                let navigationController = UINavigationController(rootViewController: rootViewController)
                window?.rootViewController = navigationController
                window?.makeKeyAndVisible()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()


    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
}

